/**
 * app.js
 * Main application logic for the Pumping Lemma Visualizer.
 * Depends on: data.js (LANGS, QUIZ)
 */

'use strict';

/* =============================================
   STATE
   ============================================= */
let curLang    = 'anbn';
let curStr     = '';
let curP       = 3;
let xEnd       = 1;
let yEnd       = 2;

let qOrder     = [];
let qIdx       = 0;
let qScore     = 0;
let qTotal     = 0;
let qAnswered  = false;


/* =============================================
   INIT
   ============================================= */
window.onload = () => {
  onLangChange();
  initQuiz();
};

/* Scroll progress bar */
window.addEventListener('scroll', () => {
  const pct = (window.scrollY / (document.body.scrollHeight - window.innerHeight)) * 100;
  document.getElementById('progress').style.width = pct + '%';
});


/* =============================================
   LANGUAGE SELECTOR
   ============================================= */
function onLangChange() {
  const v = document.getElementById('lang-sel').value;
  curLang = v;
  const L = LANGS[v];

  document.getElementById('str-in').value = L.defStr;
  document.getElementById('p-in').value   = L.defP;

  const isCustom = v === 'custom';
  document.getElementById('xend-cell').style.display = isCustom ? 'block' : 'none';
  document.getElementById('yend-cell').style.display = isCustom ? 'block' : 'none';
}


/* =============================================
   VISUALIZER — MAIN ENTRY
   ============================================= */
function runViz() {
  const L = LANGS[curLang];
  curStr = document.getElementById('str-in').value.trim();
  curP   = parseInt(document.getElementById('p-in').value) || 3;

  if (!curStr) {
    alert('Please enter a string.');
    return;
  }

  if (curLang !== 'custom') {
    /* Auto-compute a reasonable split */
    xEnd = Math.max(0, Math.min(curP - 2, Math.floor(curStr.length * 0.18)));
    yEnd = Math.min(xEnd + Math.max(1, Math.ceil(curStr.length * 0.28)), curP, curStr.length);
    if (yEnd <= xEnd) yEnd = xEnd + 1;
    if (yEnd > curStr.length) yEnd = curStr.length;
  } else {
    /* Manual split for custom mode */
    xEnd = parseInt(document.getElementById('x-end').value) || 0;
    yEnd = parseInt(document.getElementById('y-end').value) || 1;
    if (yEnd <= xEnd) { alert('y-end must be greater than x-end.'); return; }
    if (yEnd > curStr.length) { alert('y-end exceeds string length.'); return; }
  }

  /* Show panels */
  document.getElementById('viz-panel').classList.add('active');
  document.getElementById('proof-panel').classList.add('active');

  /* Build all sections */
  buildBase();
  buildConstraints();
  buildPumped(1);
  document.getElementById('pump-sl').value = 1;
  document.getElementById('pump-val').textContent = '1';
  buildProof();
  buildAccordion();

  /* Scroll to visualizer */
  setTimeout(() => {
    document.getElementById('viz-panel').scrollIntoView({ behavior: 'smooth', block: 'start' });
  }, 80);
}


/* =============================================
   CHARACTER CELL FACTORY
   ============================================= */
function mkCell(ch, cls, label, labelCls) {
  const d = document.createElement('div');
  d.className = 'char-cell ' + cls;
  let html = '';
  if (label) html += `<span class="seg-tag ${labelCls}">${label}</span>`;
  d.innerHTML = html + ch;
  return d;
}


/* =============================================
   BASE STRING DECOMPOSITION
   ============================================= */
function buildBase() {
  const t = document.getElementById('base-track');
  t.innerHTML = '';

  for (let i = 0; i < curStr.length; i++) {
    const cls = i < xEnd ? 'cx' : i < yEnd ? 'cy' : 'cz';
    let lbl = null, lcls = '';

    if (i === 0 && xEnd > 0)   { lbl = 'x'; lcls = 'tx'; }
    if (i === xEnd)             { lbl = 'y'; lcls = 'ty'; }
    if (i === yEnd)             { lbl = 'z'; lcls = 'tz'; }
    if (i === 0 && xEnd === 0)  { lbl = 'x=ε'; lcls = 'tx'; }

    t.appendChild(mkCell(curStr[i], cls, lbl, lcls));
  }

  /* Show epsilon z if z is empty */
  if (yEnd >= curStr.length) {
    const d = mkCell('ε', 'ceps', 'z', 'tz');
    d.style.opacity = '0.5';
    t.appendChild(d);
  }
}


/* =============================================
   CONSTRAINT BADGES
   ============================================= */
function buildConstraints() {
  const y   = curStr.slice(xEnd, yEnd);
  const yL  = y.length;
  const xyL = yEnd;
  const ok1 = yL >= 1;
  const ok2 = xyL <= curP;

  document.getElementById('cstrips').innerHTML = `
    <span class="ctag ${ok1 ? 'ok' : 'fail'}">|y| = ${yL} ≥ 1 ${ok1 ? '✓' : '✗'}</span>
    <span class="ctag ${ok2 ? 'ok' : 'fail'}">|xy| = ${xyL} ≤ p=${curP} ${ok2 ? '✓' : '✗'}</span>
    <span class="ctag neutral">|x| = ${xEnd}</span>
    <span class="ctag neutral">|z| = ${curStr.length - yEnd}</span>
  `;
}


/* =============================================
   PUMPED STRING RENDERER
   ============================================= */
function buildPumped(i) {
  const x      = curStr.slice(0, xEnd);
  const y      = curStr.slice(xEnd, yEnd);
  const z      = curStr.slice(yEnd);
  const pumped = x + y.repeat(i) + z;
  const L      = LANGS[curLang];
  const inL    = L.check(pumped);

  document.getElementById('i-sup').textContent = i;

  const t   = document.getElementById('pumped-track');
  t.innerHTML = '';

  const add = (ch, cls, lbl, lc) => t.appendChild(mkCell(ch, cls, lbl, lc));

  /* x segment */
  for (let k = 0; k < x.length; k++) {
    add(x[k], 'cx', k === 0 ? 'x' : null, 'tx');
  }

  /* y⁰ = ε marker */
  if (i === 0) {
    const d = document.createElement('div');
    d.className = 'char-cell ceps';
    d.innerHTML = '<span class="seg-tag ty">y⁰=ε</span>ε';
    d.style.opacity = '0.45';
    t.appendChild(d);
  }

  /* y repeated i times */
  for (let r = 0; r < i; r++) {
    for (let k = 0; k < y.length; k++) {
      const cls = r === 0 ? 'cy' : 'ce';
      const lbl = k === 0 ? (r === 0 ? 'y' : `y${r + 1}`) : null;
      add(y[k], cls, lbl, 'ty');
    }
  }

  /* z segment */
  for (let k = 0; k < z.length; k++) {
    add(z[k], 'cz', k === 0 ? 'z' : null, 'tz');
  }

  /* epsilon z */
  if (!z.length) {
    const d = mkCell('ε', 'ceps', 'z', 'tz');
    d.style.opacity = '0.5';
    t.appendChild(d);
  }

  /* Membership badge */
  const b = document.getElementById('mem-bar');
  if (inL === null) {
    b.innerHTML = `<div class="membership-bar mem-out">
      <span class="mem-icon">?</span>
      Membership unknown for custom language — "${pumped}"
    </div>`;
  } else {
    b.innerHTML = `<div class="membership-bar ${inL ? 'mem-in' : 'mem-out'}">
      <span class="mem-icon">${inL ? '✓' : '✗'}</span>
      <span>"${pumped}" ${inL
        ? '∈ L — string remains in the language'
        : '∉ L — pumping lemma condition violated!'}</span>
    </div>`;
  }
}

/* Called by pump slider */
function onPump(v) {
  const i = parseInt(v);
  document.getElementById('pump-val').textContent = i;
  buildPumped(i);
}


/* =============================================
   STEP-BY-STEP PROOF
   ============================================= */
function buildProof() {
  const L = LANGS[curLang];
  const x = curStr.slice(0, xEnd);
  const y = curStr.slice(xEnd, yEnd);
  const z = curStr.slice(yEnd);

  const regularLabel = L.regular === null
    ? 'unknown (custom)'
    : L.regular ? 'regular ✓' : 'not regular ✗';

  const steps = [
    {
      n: '01',
      html: `The language is <strong>${L.name}</strong>, which is <strong>${regularLabel}</strong>.`
    },
    {
      n: '02',
      html: `We examine the string <strong>s = "${curStr}"</strong> with |s| = ${curStr.length}.
             The chosen pumping length is <strong>p = ${curP}</strong>.`
    },
    {
      n: '03',
      html: `We decompose s into xyz:
             x = <code>${x || 'ε'}</code>,
             y = <code>${y}</code>,
             z = <code>${z || 'ε'}</code>.
             Constraints: |y| = ${y.length} ≥ 1; |xy| = ${xEnd + y.length} ≤ ${curP}.`
    },
    {
      n: '04',
      html: L.regular === false
        ? `We pump y with i ≠ 1. The resulting string leaves L,
           providing a <strong>contradiction</strong> that proves L is not regular.`
        : `Pumping y any number of times keeps the string in L — consistent with regularity.`
    }
  ];

  if (L.why && L.regular === false) {
    steps.push({ n: '05', html: `<strong>Key insight:</strong> ${L.why}` });
  }

  let g = '';
  steps.forEach(s => {
    g += `<div class="proof-step-num">${s.n}</div><div class="proof-step-body">${s.html}</div>`;
  });
  document.getElementById('proof-grid').innerHTML = g;
}


/* =============================================
   ACCORDION — FAQ ABOUT THE DECOMPOSITION
   ============================================= */
function buildAccordion() {
  const L = LANGS[curLang];
  const x = curStr.slice(0, xEnd);
  const y = curStr.slice(xEnd, yEnd);
  const z = curStr.slice(yEnd);

  const items = [
    {
      q: 'What is x?',
      a: `${L.xd} Here x = <code>${x || 'ε'}</code>.`
    },
    {
      q: 'What is y?',
      a: `${L.yd} Here y = <code>${y}</code>.`
    },
    {
      q: 'What is z?',
      a: `${L.zd} Here z = <code>${z || 'ε'}</code>.`
    },
    {
      q: 'What does pumping mean?',
      a: `Replacing y with y<sup>i</sup> gives xy<sup>i</sup>z. For a regular language, every
          valid split must produce strings that stay in L for all i ≥ 0. If any i violates
          membership, the language cannot be regular.`
    },
    {
      q: 'How does this prove non-regularity?',
      a: L.regular === false
        ? `For the chosen decomposition, no value of i (other than i = 1) keeps the string in L.
           Since this holds for every valid split, no finite automaton can recognize L —
           therefore L is not regular.`
        : `For this regular language, every valid split produces strings that remain in L under
           pumping — fully consistent with regularity.`
    }
  ];

  document.getElementById('accordion').innerHTML = items.map((it, idx) => `
    <div class="acc-item">
      <button class="acc-btn" onclick="toggleAcc(${idx})">
        ${it.q}<span class="acc-arrow" id="arr${idx}">+</span>
      </button>
      <div class="acc-body" id="ab${idx}">${it.a}</div>
    </div>
  `).join('');
}

function toggleAcc(i) {
  const body  = document.getElementById('ab'  + i);
  const arrow = document.getElementById('arr' + i);
  const isOpen = body.classList.contains('open');
  body.classList.toggle('open', !isOpen);
  arrow.classList.toggle('open', !isOpen);
  arrow.textContent = isOpen ? '+' : '×';
}


/* =============================================
   QUIZ
   ============================================= */
function initQuiz() {
  qOrder = [...QUIZ.keys()].sort(() => Math.random() - 0.5);
  qIdx   = 0;
  qScore = 0;
  qTotal = 0;
  renderQuiz();
}

function resetQuiz() {
  initQuiz();
}

function renderQuiz() {
  qAnswered = false;
  const q = QUIZ[qOrder[qIdx % qOrder.length]];

  document.getElementById('qq').textContent   = q.q;
  document.getElementById('qfb').className    = 'quiz-fb';
  document.getElementById('qnext').className  = 'quiz-next';
  document.getElementById('qopts').innerHTML  = `
    <button class="quiz-opt" onclick="ansQ(true, this)">&#10003; &nbsp;Yes, regular</button>
    <button class="quiz-opt" onclick="ansQ(false, this)">&#10007; &nbsp;Not regular</button>
  `;
}

function ansQ(ans, btn) {
  if (qAnswered) return;
  qAnswered = true;
  qTotal++;

  const q  = QUIZ[qOrder[qIdx % qOrder.length]];
  const ok = ans === q.a;
  if (ok) qScore++;

  document.getElementById('qscore').textContent = `${qScore} / ${qTotal}`;

  /* Reveal correct option */
  document.querySelectorAll('.quiz-opt').forEach(o => {
    if (o.textContent.includes('Yes') === q.a) o.classList.add('reveal');
  });
  btn.classList.add(ok ? 'correct' : 'wrong');

  /* Show feedback */
  const fb = document.getElementById('qfb');
  fb.className = 'quiz-fb show ' + (ok ? 'ok' : 'bad');
  fb.innerHTML = (ok ? '<strong>Correct.</strong> ' : '<strong>Incorrect.</strong> ') + q.exp;

  document.getElementById('qnext').className = 'quiz-next show';
}

function nextQuiz() {
  qIdx++;
  if (qIdx >= qOrder.length) {
    /* Reshuffle when all questions have been shown */
    qOrder = [...QUIZ.keys()].sort(() => Math.random() - 0.5);
    qIdx   = 0;
  }
  renderQuiz();
}
